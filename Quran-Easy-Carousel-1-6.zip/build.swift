import AppKit
import CoreGraphics

let root = URL(fileURLWithPath: CommandLine.arguments[1])
let source = root.appendingPathComponent("Sources")
let W = 6480, H = 1920
func color(_ hex: UInt32, _ alpha: CGFloat = 1) -> NSColor {
    NSColor(srgbRed: CGFloat((hex >> 16) & 255)/255, green: CGFloat((hex >> 8) & 255)/255, blue: CGFloat(hex & 255)/255, alpha: alpha)
}
func canvas(_ w: Int, _ h: Int) -> CGContext {
    CGContext(data:nil, width:w, height:h, bitsPerComponent:8, bytesPerRow:w*4, space:CGColorSpace(name:CGColorSpace.sRGB)!, bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue)!
}
func start(_ c: CGContext, _ h:Int) {
    c.translateBy(x:0,y:CGFloat(h)); c.scaleBy(x:1,y:-1)
    NSGraphicsContext.current = NSGraphicsContext(cgContext:c,flipped:true)
    c.interpolationQuality = .high
}
func save(_ image: CGImage, _ name: String) throws {
    let rep = NSBitmapImageRep(cgImage:image)
    try rep.representation(using:.png,properties:[:])!.write(to:root.appendingPathComponent(name))
}
func text(_ string:String, x:CGFloat, y:CGFloat, size:CGFloat, weight:NSFont.Weight = .regular, ink:NSColor, tracking:CGFloat=0) {
    let font = NSFont.systemFont(ofSize:size,weight:weight)
    (string as NSString).draw(at:NSPoint(x:x,y:y), withAttributes:[.font:font,.foregroundColor:ink,.kern:tracking])
}
let c=canvas(W,H); start(c,H)
let bg=NSImage(contentsOf:source.appendingPathComponent("Background.png"))!
bg.draw(in:NSRect(x:0,y:0,width:W,height:H),from:.zero,operation:.copy,fraction:1,respectFlipped:true,hints:nil)
// A quiet header wash keeps every headline readable across the continuous scene.
NSGradient(colors:[color(0x001519,0.62),color(0x001519,0)])!.draw(in:NSRect(x:0,y:0,width:W,height:640),angle:90)
let ivory=color(0xF1FFFA), aqua=color(0x31DED0), muted=color(0xB7D2CF)
let titles:[(String,String,String)] = [
    ("FIND YOUR", "QIBLA.", "A clear direction to Makkah"),
    ("READ. LISTEN.", "REFLECT.", "Your daily Quran companion"),
    ("READ WITH", "CLARITY.", "114 Surahs. 30 Juz."),
    ("FIND", "HOPE.", "Guidance for every feeling"),
    ("DAILY", "DHIKR.", "Count with intention"),
    ("RECITE", "MANZIL.", "Read and listen with ease")
]
for (i,t) in titles.enumerated() {
    let x=CGFloat(i*1080+84)
    text("QURAN EASY",x:x,y:70,size:28,weight:.semibold,ink:color(0xA6E9DC),tracking:3)
    text(String(format:"%02d / 06",i+1),x:x+748,y:73,size:24,weight:.medium,ink:muted,tracking:2)
    aqua.setFill(); NSBezierPath(roundedRect:NSRect(x:x,y:130,width:74,height:5),xRadius:2.5,yRadius:2.5).fill()
    text(t.0,x:x-3,y:185,size:i == 1 ? 89:96,weight:.bold,ink:ivory,tracking:-2.5)
    text(t.1,x:x-5,y:285,size:137,weight:.bold,ink:aqua,tracking:-5)
    text(t.2,x:x,y:452,size:37,weight:.regular,ink:muted,tracking:0)
}

// Phone objects are placed on the master, not independently on the six slices.
// Objects crossing a 1080 px seam therefore join perfectly when swiped.
func phone(_ name:String, center:CGFloat, top:CGFloat, width:CGFloat, angle:CGFloat) {
    let image=NSImage(contentsOf:source.appendingPathComponent(name))!
    let height=width*image.size.height/image.size.width
    c.saveGState()
    c.translateBy(x:center,y:top+height/2)
    c.rotate(by:angle * .pi/180)
    let r=NSRect(x:-width/2,y:-height/2,width:width,height:height)
    let outer=r.insetBy(dx:-11,dy:-11)
    let shape=NSBezierPath(roundedRect:outer,xRadius:width*0.1,yRadius:width*0.1)
    c.setShadow(offset:CGSize(width:0,height:18),blur:32,color:color(0x000000,0.65).cgColor)
    color(0x081518).setFill(); shape.fill()
    c.setShadow(offset:.zero,blur:0,color:nil)
    color(0xA3C3BF).setStroke(); shape.lineWidth=2.4; shape.stroke()
    let rim=NSBezierPath(roundedRect:r.insetBy(dx:-6,dy:-6),xRadius:width*0.095,yRadius:width*0.095)
    color(0x365B5B).setStroke(); rim.lineWidth=3; rim.stroke()
    c.saveGState()
    NSBezierPath(roundedRect:r,xRadius:width*0.09,yRadius:width*0.09).addClip()
    image.draw(in:r,from:.zero,operation:.sourceOver,fraction:1,respectFlipped:true,hints:nil)
    c.restoreGState(); c.restoreGState()
}
phone("Screenshot_20261120_231349.png", center:1125,top:605,width:580,angle:5)
phone("Screenshot_20261120_231354.png", center:2205,top:600,width:580,angle:-5)
phone("Screenshot_20261120_235438.png", center:3285,top:600,width:580,angle:5)
phone("Screenshot_20261120_231409.png", center:4365,top:600,width:580,angle:-5)
phone("Screenshot_20261120_231418.png", center:5445,top:600,width:580,angle:5)
phone("Screenshot_20261127_215314.png", center:430,top:585,width:578,angle:-5)
phone("Screenshot_20261120_231422.png", center:6070,top:590,width:578,angle:5)
let master=c.makeImage()!
try save(master,"Master-Canvas.png")
for i in 0..<6 {
    try save(master.cropping(to:CGRect(x:i*1080,y:0,width:1080,height:H))!,"\(i+1).png")
}
// Contact sheet is only a review aid; exports are exact lossless master crops.
let review=canvas(1620,1920); start(review,1920)
color(0x071616).setFill(); NSBezierPath(rect:NSRect(x:0,y:0,width:1620,height:1920)).fill()
for i in 0..<6 {
    let img=NSImage(cgImage:master.cropping(to:CGRect(x:i*1080,y:0,width:1080,height:H))!,size:NSSize(width:1080,height:H))
    img.draw(in:NSRect(x:(i%3)*540,y:(i/3)*960,width:540,height:960),from:.zero,operation:.sourceOver,fraction:1,respectFlipped:true,hints:nil)
}
try save(review.makeImage()!,"Preview.png")
print("Exported one 6480 × 1920 master and six exact 1080 × 1920 slices.")
